﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Voting.Core.Models
{
    public class Categories
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public DateTimeOffset CreatedOn { get; set; }
        public ICollection<Candidates> Candidates { get; set; }
    }
}
