﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Voting.Core.Models
{
    public class Votes
    {
        public Votes()
        {

        }
        public Guid Id { get; } = Guid.NewGuid();
        public Guid CandidateId { get; set; }
        public Candidates Candidate { get; set; }
        public Guid VoterId { get; set; }
        public Voters Voter { get; set; }
       // public Guid CategoryId { get; set; }
      //  public Categories Category { get; set; }
        public DateTimeOffset CreatedOn { get; set; }
        
    }
}
