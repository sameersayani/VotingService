﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Voting.Core.Models
{
    public class Candidates
    {
        public Guid Id { get; set; }
        public string Firstname { get; set; }
        public string Middlename { get; set; }
        public string Lastname { get; set; }
        public Guid CategoryId { get; set; }
        public Categories Category { get; set; }
        public DateTimeOffset CreatedOn { get; set; }
       
    }
}
