using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Voting.Core.Models;

namespace Voting.Core.Repositories
{
    public interface IVoterRepository : IRepository<Voters>
    {
        Task<IEnumerable<Voters>> GetVotersAsync();
        Task<Voters> GetVoterById(Guid Id);
    }
}