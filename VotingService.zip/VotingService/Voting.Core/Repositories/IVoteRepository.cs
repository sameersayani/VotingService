using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Voting.Core.Models;

namespace Voting.Core.Repositories
{
    public interface IVotesRepository : IRepository<Votes>
    {
        Task<Votes> GetVotesById(Guid Id);
        Task<IEnumerable<Votes>> GetVotesByCandidateId(Guid Id);
        Task<IEnumerable<Votes>> GetVotesForCandidatePerCategoryByVoter(Guid VoterId, Guid CandidateId);
    }
}