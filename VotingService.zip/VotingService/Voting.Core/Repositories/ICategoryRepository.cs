using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Voting.Core.Models;

namespace Voting.Core.Repositories
{
    public interface ICategoryRepository : IRepository<Categories>
    {
        Task<IEnumerable<Categories>> GetCategoriesAsync();
        Task<Categories> GetCategoryByIdAsync(Guid Id);
    }
}