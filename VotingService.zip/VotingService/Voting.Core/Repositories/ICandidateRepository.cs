using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Voting.Core.Models;

namespace Voting.Core.Repositories
{
    public interface ICandidateRepository : IRepository<Candidates>
    {
        Task<IEnumerable<Candidates>> GetCandidatesAsync();
        Task<IEnumerable<Candidates>> GetCandidatesByCategoryAsync(Guid Id);
        Task<Candidates> GetCandidateByIdAsync(Guid Id);
    }
}