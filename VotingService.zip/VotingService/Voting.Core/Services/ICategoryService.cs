using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Voting.Core.Models;

namespace Voting.Core.Services
{
    public interface ICategoryService
    {
        Task<IEnumerable<Categories>> GetCategories();
        Task<Categories> GetCategoryById(Guid Id);
        Task<Categories> CreateCategory(Categories newCategory);
    }
}