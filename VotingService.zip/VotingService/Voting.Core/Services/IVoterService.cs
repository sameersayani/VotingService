using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Voting.Core.Models;

namespace Voting.Core.Services
{
    public interface IVoterService
    {
        Task<IEnumerable<Voters>> GetVoters();
        Task<Voters> GetVoterById(Guid voterId);
        Task<Voters> CreateVoter(Voters newVoter);
        Task UpdateVoterAge(Voters voterToBeUpdated, Voters voter);
        Task DeleteVoter(Voters voter);
    }
}