using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Voting.Core.Models;

namespace Voting.Core.Services
{
    public interface IVotesService
    {
        Task<Votes> GetVotesById(Guid Id);
        Task<IEnumerable<Votes>> GetVotesForCandidate(Guid candidateId);
        Task<IEnumerable<Votes>> GetVotesForCandidatePerCategoryByVoter(Guid VoterId, Guid CandidateId);
        Task<Votes> CreateVote(Votes voteToCreate);
    }
}