using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Voting.Core.Models;

namespace Voting.Core.Services
{
    public interface ICandidateService
    {
        Task<IEnumerable<Candidates>> GetCandidates();
        Task<Candidates> GetCandidateById(Guid Id);
        Task<IEnumerable<Candidates>> GetCandidatesByCategoryId(Guid categoryId);
        Task<Candidates> CreateCandidate(Candidates newCandidate);
    }
}