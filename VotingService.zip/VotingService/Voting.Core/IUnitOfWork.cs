using System;
using System.Threading.Tasks;
using Voting.Core.Repositories;

namespace Voting.Core
{
    public interface IUnitOfWork : IDisposable
    {
        ICategoryRepository Categories { get; }
        ICandidateRepository Candidates { get; }
        IVoterRepository Voters { get; }
        IVotesRepository Votes { get; }
        Task<int> CommitAsync();
    }
}