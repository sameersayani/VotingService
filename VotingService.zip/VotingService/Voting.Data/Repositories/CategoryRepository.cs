using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Voting.Data.Repositories;
using Voting.Core.Models;
using Voting.Core.Repositories;

namespace Voting.Data.Repositories
{
    public class CategoryRepository : Repository<Categories>, ICategoryRepository
    {
        public CategoryRepository(VotingDbContext context) 
            : base(context)
        { }
 
        public async Task<IEnumerable<Categories>> GetCategoriesAsync()
        {
            return await VotingDbContext.Categories
               .ToListAsync();
        }

        public async Task<Categories> GetCategoryByIdAsync(Guid Id)
        {
            return await VotingDbContext.Categories
                .SingleOrDefaultAsync(a => a.Id == Id);
        }

        private VotingDbContext VotingDbContext
        {
            get { return Context as VotingDbContext; }
        }
    }
}