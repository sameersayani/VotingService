using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Voting.Data.Repositories;
using Voting.Core.Models;
using Voting.Core.Repositories;
using System.Linq;

namespace Voting.Data.Repositories
{
    public class CandidateRepository : Repository<Candidates>, ICandidateRepository
    {
        public CandidateRepository(VotingDbContext context) 
            : base(context)
        { }
 
        public async Task<IEnumerable<Categories>> GetCategoriesAsync()
        {
            return await VotingDbContext.Categories
               .ToListAsync();
        }

        public async Task<Categories> GetCategoryByIdAsync(Guid Id)
        {
            return await VotingDbContext.Categories
                .SingleOrDefaultAsync(a => a.Id == Id);
        }

        public async Task<IEnumerable<Candidates>> GetCandidatesAsync()
        {
            return await VotingDbContext.Candidates
               .ToListAsync();
        }

        public async Task<IEnumerable<Candidates>> GetCandidatesByCategoryAsync(Guid Id)
        {
            return await VotingDbContext.Candidates.Where(x => x.CategoryId == Id)
              .ToListAsync();
        }

        public async Task<Candidates> GetCandidateByIdAsync(Guid Id)
        {
            return await VotingDbContext.Candidates
                .SingleOrDefaultAsync(a => a.Id == Id);
        }

        private VotingDbContext VotingDbContext
        {
            get { return Context as VotingDbContext; }
        }
    }
}