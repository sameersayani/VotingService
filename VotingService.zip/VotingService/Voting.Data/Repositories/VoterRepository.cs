using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Voting.Data.Repositories;
using Voting.Core.Models;
using Voting.Core.Repositories;
using System.Linq;

namespace Voting.Data.Repositories
{
    public class VoterRepository : Repository<Voters>, IVoterRepository
    {
        public VoterRepository(VotingDbContext context) 
            : base(context)
        { }

        public async Task<IEnumerable<Voters>> GetVotersAsync()
        {
            return await VotingDbContext.Voters.ToListAsync();
        }

        public async Task<Voters> GetVoterById(Guid Id)
        {
            return await VotingDbContext.Voters
               .SingleOrDefaultAsync(a => a.Id == Id);
        }

        private VotingDbContext VotingDbContext
        {
            get { return Context as VotingDbContext; }
        }
    }
}