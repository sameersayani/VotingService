using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Voting.Data.Repositories;
using Voting.Core.Models;
using Voting.Core.Repositories;
using System.Linq;
using System.Linq.Expressions;

namespace Voting.Data.Repositories
{
    public class VoteRepository : Repository<Votes>, IVotesRepository
    {
        public VoteRepository(VotingDbContext context) 
            : base(context)
        { }

        public async Task<IEnumerable<Votes>> GetVotesByCandidateId(Guid Id)
        {
            return await VotingDbContext.Votes
                .Include(m => m.Candidate)
                .Where(m => m.CandidateId == Id).ToListAsync();   
        }

        public async Task<IEnumerable<Votes>> GetVotesForCandidatePerCategoryByVoter(Guid VoterId, Guid CandidateId)
        {
            var candidateAndCategory = await VotingDbContext.Candidates
                .Include(m => m.Category)
                .SingleOrDefaultAsync(m => m.Id == CandidateId);

            var voter = await VotingDbContext.Voters
               .SingleOrDefaultAsync(v => v.Id == VoterId);

            var v =  await VotingDbContext.Votes
               // .Where(m => m.CandidateId == candidateAndCategory.Id)
                .Where(m=>m.Candidate.CategoryId == candidateAndCategory.Category.Id)
                .Where(o => o.VoterId == voter.Id)
                .ToListAsync();
            return v;
        }

        public IEnumerable<Votes> Find(Expression<Func<Votes, bool>> predicate)
        {
            throw new NotImplementedException();
        }

        public async Task<Votes> GetVotesById(Guid Id)
        {
            return await VotingDbContext.Votes
               .SingleOrDefaultAsync(a => a.Id == Id);
        }

        private VotingDbContext VotingDbContext
        {
            get { return Context as VotingDbContext; }
        }
    }
}