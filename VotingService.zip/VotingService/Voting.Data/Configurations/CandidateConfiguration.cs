using Voting.Core.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Voting.Data.Configurations
{
    public class CandidateConfiguration : IEntityTypeConfiguration<Candidates>
    {
        public void Configure(EntityTypeBuilder<Candidates> builder)
        {
            builder
                .HasKey(m => m.Id);

            builder
                .Property(m => m.Id);
                
            builder
                .Property(m => m.Firstname)
                .IsRequired()
                .HasMaxLength(100);

            builder
                .Property(m => m.Lastname)
                .IsRequired()
                .HasMaxLength(100);

            builder
                .HasOne(m => m.Category)
                .WithMany(a => a.Candidates)
                .HasForeignKey(m => m.CategoryId);

            builder
                .Property(m => m.CategoryId)
                .IsRequired();
        }
    }
}