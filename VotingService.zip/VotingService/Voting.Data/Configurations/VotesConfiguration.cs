using Voting.Core.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Voting.Data.Configurations
{
    public class VotesConfiguration : IEntityTypeConfiguration<Votes>
    {
        public void Configure(EntityTypeBuilder<Votes> builder)
        {
            builder
                .HasKey(m => m.Id);

            builder
                .Property(m => m.Id);

            builder
                .Property(m => m.CandidateId)
                .IsRequired();

            builder
                .Property(m => m.VoterId)
                .IsRequired();
        }
    }
}