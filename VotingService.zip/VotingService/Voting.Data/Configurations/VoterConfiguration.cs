using Voting.Core.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Voting.Data.Configurations
{
    public class VoterConfiguration : IEntityTypeConfiguration<Voters>
    {
        public void Configure(EntityTypeBuilder<Voters> builder)
        {
            builder
                .HasKey(m => m.Id);

            builder
                .Property(m => m.Id);
                
            builder
                .Property(m => m.Firstname)
                .IsRequired()
                .HasMaxLength(100);

            builder
                .Property(m => m.Lastname)
                .IsRequired()
                .HasMaxLength(100);

            builder
                .Property(m => m.DateOfBirth)
                .IsRequired();

            builder
                .Property(m => m.Email)
                .IsRequired()
                .HasMaxLength(100);

        }
    }
}