using System.Threading.Tasks;
using Voting.Core;
using Voting.Core.Repositories;
using Voting.Data;
using Voting.Data.Repositories;

namespace Voting.Data
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly VotingDbContext _context;
        private CategoryRepository _categoryRepository;
        private CandidateRepository _candidateRepository;
        private VoterRepository _voterRepository;
        private VoteRepository _votesRepository;
        public UnitOfWork(VotingDbContext context)
        {
            this._context = context;
        }

        public IVotesRepository Votes =>
            _votesRepository = _votesRepository ?? new VoteRepository(_context);

        public IVoterRepository Voters =>
            _voterRepository = _voterRepository ?? new VoterRepository(_context);

        public ICategoryRepository Categories => 
            _categoryRepository = _categoryRepository ?? new CategoryRepository(_context);

        public ICandidateRepository Candidates =>
            _candidateRepository = _candidateRepository ?? new CandidateRepository(_context);

        public async Task<int> CommitAsync()
        {
            return await _context.SaveChangesAsync();
        }

        public void Dispose()
        {
            _context.Dispose();
        }
    }
}