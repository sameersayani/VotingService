﻿using Microsoft.EntityFrameworkCore;
using Voting.Data.Configurations;
using Voting.Core.Models;
using Voting.Data.Repositories;

namespace Voting.Data
{
    public class VotingDbContext : DbContext
    {
        public DbSet<Categories> Categories { get; set; }
        public DbSet<Candidates> Candidates { get; set; }
        public DbSet<Voters> Voters { get; set; }
        public DbSet<Votes> Votes { get; set; }
        public VotingDbContext(DbContextOptions<VotingDbContext> options)
            : base(options)
        { }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.ApplyConfiguration(new CategoryConfiguration());
            builder.ApplyConfiguration(new CandidateConfiguration());
            builder.ApplyConfiguration(new VoterConfiguration());
            builder.ApplyConfiguration(new VotesConfiguration());
        }
    }
}
