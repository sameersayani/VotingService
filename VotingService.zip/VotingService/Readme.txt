********* Voting System *********
1. Set up Database by running the Db scripts
2. Change the connection string as per your database in appsettings.json file.
3. Use Swagger to test the API.
4. Check for valid Guid while testing.


