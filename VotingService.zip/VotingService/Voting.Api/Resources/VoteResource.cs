using System;

namespace Voting.Api.Resources
{
    public class VoteResource
    {
        public Guid Id { get; } = Guid.NewGuid();
        public Guid CandidateId { get; set; }
        public Guid VoterId { get; set; }
        //public Guid CategoryId { get; set; }
        public DateTimeOffset CreatedOn { get; set; }
    }
}