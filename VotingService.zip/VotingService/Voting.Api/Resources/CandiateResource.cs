using System;

namespace Voting.Api.Resources
{
    public class CandiateResource
    {
        public Guid Id { get; } = Guid.NewGuid();
        public string Firstname { get; set; }
        public string Middlename { get; set; }
        public string Lastname { get; set; }
        public Guid CategoryId { get; set; }
        public DateTimeOffset CreatedOn { get; set; }
    }
}