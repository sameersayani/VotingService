using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Voting.Api.Resources;
using Voting.Api.Validations;
using Voting.Core.Models;
using Voting.Core.Services;

namespace Voting.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VoterController : ControllerBase
    {
        private readonly IVoterService _voterService;
        private readonly IMapper _mapper;
        
        public VoterController(IVoterService voterService, IMapper mapper)
        {
            this._mapper = mapper;
            this._voterService = voterService;
        }

        [HttpGet("")]
        public async Task<ActionResult<IEnumerable<VoterResource>>> GetVoters()
        {
            var voters = await _voterService.GetVoters();
            var voterResources = _mapper.Map<IEnumerable<Voters>, IEnumerable<VoterResource>>(voters);

            return Ok(voterResources);
        }

        [HttpGet("{Id}")]
        public async Task<ActionResult<VoterResource>> GetVoterById(Guid Id)
        {
            var voter = await _voterService.GetVoterById(Id);
            var voterResources = _mapper.Map<Voters, VoterResource>(voter);

            return Ok(voterResources);
        }

        [HttpPost("")]
        public async Task<ActionResult<VoterResource>> CreateVoter([FromBody] VoterResource saveVoterResource)
        {
            var validator = new SaveVoterResourceValidator();
            var validationResult = await validator.ValidateAsync(saveVoterResource);

            if (!validationResult.IsValid)
                return BadRequest(validationResult.Errors); 

            var voterToCreate = _mapper.Map<VoterResource, Voters>(saveVoterResource);

            var newvoter = await _voterService.CreateVoter(voterToCreate);

            var voter = await _voterService.GetVoterById(newvoter.Id);

            var voterResource = _mapper.Map<Voters, VoterResource>(voter);

            return Ok(voterResource);
        }

        [HttpPut("{id}")]
        public async Task<ActionResult<VoterResource>> UpdateVoter(Guid id, [FromBody] VoterResource saveVoterResource)
        {
            var validator = new SaveVoterResourceValidator();
            var validationResult = await validator.ValidateAsync(saveVoterResource);

            var requestIsInvalid = id == Guid.Empty || !validationResult.IsValid;

            if (requestIsInvalid)
                return BadRequest(validationResult.Errors); 

            var voterToBeUpdate = await _voterService.GetVoterById(id);

            if (voterToBeUpdate == null)
                return NotFound();

            var voter = _mapper.Map<VoterResource, Voters>(saveVoterResource);

            await _voterService.UpdateVoterAge(voterToBeUpdate, voter);

            var updatedVoter = await _voterService.GetVoterById(id);
            var updatedVoterResource = _mapper.Map<Voters, VoterResource>(updatedVoter);

            return Ok(updatedVoterResource);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteVoter(Guid id)
        {
            if (id == Guid.Empty)
                return BadRequest();

            var voter = await _voterService.GetVoterById(id);

            if (voter == null)
                return NotFound();

            await _voterService.DeleteVoter(voter);

            return NoContent();
        }
    }
}