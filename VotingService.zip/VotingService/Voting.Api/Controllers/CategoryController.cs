using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Voting.Api.Resources;
using Voting.Api.Validations;
using Voting.Core.Models;
using Voting.Core.Services;

namespace Voting.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoryController : ControllerBase
    {
        private readonly ICategoryService _categoryService;
        private readonly IMapper _mapper;
        
        public CategoryController(ICategoryService categoryService, IMapper mapper)
        {
            this._mapper = mapper;
            this._categoryService = categoryService;
        }

        [HttpGet("")]
        public async Task<ActionResult<IEnumerable<CategoryResource>>> GetCategories()
        {
            var categories = await _categoryService.GetCategories();
            var categoryResources = _mapper.Map<IEnumerable<Categories>, IEnumerable<CategoryResource>>(categories);

            return Ok(categoryResources);
        }

        [HttpGet("{Id}")]
        public async Task<ActionResult<CategoryResource>> GetCategoryById(Guid Id)
        {
            var category = await _categoryService.GetCategoryById(Id);
            var categoryResources = _mapper.Map<Categories, CategoryResource>(category);

            return Ok(categoryResources);
        }

        [HttpPost("")]
        public async Task<ActionResult<CategoryResource>> CreateCategory([FromBody] CategoryResource saveCategoryResource)
        {
            var validator = new SaveCategoryResourceValidator();
            var validationResult = await validator.ValidateAsync(saveCategoryResource);

            if (!validationResult.IsValid)
                return BadRequest(validationResult.Errors); 

            var categoryToCreate = _mapper.Map<CategoryResource, Categories>(saveCategoryResource);

            var newcategory = await _categoryService.CreateCategory(categoryToCreate);

            var category = await _categoryService.GetCategoryById(newcategory.Id);

            var categoryResource = _mapper.Map<Categories, CategoryResource>(category);

            return Ok(categoryResource);
        }
    }
}