using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Voting.Api.Resources;
using Voting.Api.Validations;
using Voting.Core.Models;
using Voting.Core.Services;

namespace Voting.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CandidateController : ControllerBase
    {
        private readonly ICandidateService _candidateService;
        private readonly IMapper _mapper;
        
        public CandidateController(ICandidateService candidateService, IMapper mapper)
        {
            this._mapper = mapper;
            this._candidateService = candidateService;
        }

        [HttpGet("")]
        public async Task<ActionResult<IEnumerable<CandiateResource>>> GetCandidates()
        {
            var candidates = await _candidateService.GetCandidates();
            var candidateResources = _mapper.Map<IEnumerable<Candidates>, IEnumerable<CandiateResource>>(candidates);

            return Ok(candidateResources);
        }

        [HttpGet("{Id}")]
        public async Task<ActionResult<IEnumerable<CandiateResource>>> GetCandiatesByCategoryId(Guid Id)
        {
            var candidates = await _candidateService.GetCandidatesByCategoryId(Id);
            var candidateResources = _mapper.Map<IEnumerable<Candidates>, IEnumerable<CandiateResource>>(candidates);

            return Ok(candidateResources);
        }

        [HttpPost("")]
        public async Task<ActionResult<CandiateResource>> CreateCategory([FromBody] CandiateResource saveCandidateResource)
        {
            var validator = new SaveCandidateResourceValidator();
            var validationResult = await validator.ValidateAsync(saveCandidateResource);

            if (!validationResult.IsValid)
                return BadRequest(validationResult.Errors); 

            var candidateToCreate = _mapper.Map<CandiateResource, Candidates>(saveCandidateResource);

            var newcandidate = await _candidateService.CreateCandidate(candidateToCreate);

            var candidate = await _candidateService.GetCandidateById(newcandidate.Id);

            var categoryResource = _mapper.Map<Candidates, CandiateResource>(candidate);

            return Ok(categoryResource);
        }
    }
}