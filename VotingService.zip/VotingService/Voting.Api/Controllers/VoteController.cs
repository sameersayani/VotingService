using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Voting.Api.Resources;
using Voting.Api.Validations;
using Voting.Core.Models;
using Voting.Core.Services;

namespace Voting.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VoteController : ControllerBase
    {
        private readonly IVotesService _voteService;
        private readonly IMapper _mapper;
        
        public VoteController(IVotesService voteService, IMapper mapper)
        {
            this._mapper = mapper;
            this._voteService = voteService;
        }

        [HttpGet("{Id}")]
        public async Task<ActionResult<VoteResource>> GetVotesByCandidateId(Guid Id)
        {
            var votes = await _voteService.GetVotesForCandidate(Id);
            var voteResources = _mapper.Map<IEnumerable<Votes>, IEnumerable<VoteResource>>(votes);

            return Ok(voteResources);
        }

        [HttpGet("{VoterId}/{CandidateId}")]
        public async Task<ActionResult<VoteResource>> GetVotesForCandidatePerCategoryByVoter(Guid VoterId, Guid CandidateId)
        {
            var votes = await _voteService.GetVotesForCandidatePerCategoryByVoter(VoterId, CandidateId);
            var voteResources = _mapper.Map<IEnumerable<Votes>, IEnumerable<VoteResource>>(votes);

            return Ok(voteResources);
        }

        [HttpPost("")]
        public async Task<ActionResult<VoteResource>> CreateVoter([FromBody] VoteResource saveVoteResource)
        {
            var validator = new SaveVoteResourceValidator();
            var validationResult = await validator.ValidateAsync(saveVoteResource);

            if (!validationResult.IsValid)
                return BadRequest(validationResult.Errors); 

            var voteToCreate = _mapper.Map<VoteResource, Votes>(saveVoteResource);

            var newvote = await _voteService.CreateVote(voteToCreate);

            var vote = await _voteService.GetVotesById(newvote.Id);

            var voteResource = _mapper.Map<Votes, VoteResource>(vote);

            if (vote == null && newvote.VoterId == Guid.Empty)
            {
                return BadRequest("Voter's age is less than 18 so can't vote");
            }
            else if (vote == null && newvote.CandidateId == Guid.Empty)
            {
                return BadRequest("Candidate already been voted under said category so can't vote");
            }
           
            return Ok(voteResource);
        }

    }
}