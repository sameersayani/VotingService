using FluentValidation;
using Voting.Api.Resources;

namespace Voting.Api.Validations
{
    public class SaveCategoryResourceValidator : AbstractValidator<CategoryResource>
    {
        public SaveCategoryResourceValidator()
        {
            RuleFor(a => a.Name)
                .NotEmpty()
                .MaximumLength(100);
        }
    }
}