using FluentValidation;
using System;
using Voting.Api.Resources;

namespace Voting.Api.Validations
{
    public class SaveVoterResourceValidator : AbstractValidator<VoterResource>
    {
        public SaveVoterResourceValidator()
        {
            RuleFor(a => a.Firstname)
                .NotEmpty()
                .MaximumLength(100)
                .WithMessage("Firstname is required");

            RuleFor(a => a.Lastname)
                .NotEmpty()
                .MaximumLength(100)
                .WithMessage("Lastname is required");

            RuleFor(a => a.DateOfBirth)
                .NotEmpty()
                .NotNull()
                .WithMessage("Date of birth is required");

            RuleFor(f =>
            f.DateOfBirth).Cascade(CascadeMode.StopOnFirstFailure).NotEmpty()
                        .Must(date => date != default(DateTimeOffset))
                        .WithMessage("Date should be in yyyy-mm-dd format");
            }
    }
}