using FluentValidation;
using Voting.Api.Resources;

namespace Voting.Api.Validations
{
    public class SaveCandidateResourceValidator : AbstractValidator<CandiateResource>
    {
        public SaveCandidateResourceValidator()
        {
            RuleFor(a => a.Firstname)
                .NotEmpty()
                .MaximumLength(100);

            RuleFor(a => a.Lastname)
                .NotEmpty()
                .MaximumLength(100);

            RuleFor(a => a.CategoryId)
                .NotEmpty();
        }
    }
}