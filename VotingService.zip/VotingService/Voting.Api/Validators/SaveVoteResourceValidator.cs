using FluentValidation;
using System;
using Voting.Api.Resources;

namespace Voting.Api.Validations
{
    public class SaveVoteResourceValidator : AbstractValidator<VoteResource>
    {
        public SaveVoteResourceValidator()
        {
            RuleFor(a => a.CandidateId)
                .NotEmpty()
                .WithMessage("Candidate is required for whom vote is made");

            RuleFor(a => a.VoterId)
                .NotEmpty()
                .WithMessage("Voter is required to vote for candidate");
        }
    }
}