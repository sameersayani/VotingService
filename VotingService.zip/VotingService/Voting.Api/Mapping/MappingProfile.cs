using AutoMapper;
using Voting.Api.Resources;
using Voting.Core.Models;

namespace Voting.Api.Mapping
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            // Domain to Resource
            CreateMap<Categories, CategoryResource>();
            CreateMap<Candidates, CandiateResource>();
            CreateMap<Voters, VoterResource>();
            CreateMap<Votes, VoteResource>();

            // Resource to Domain
            CreateMap<CategoryResource, Categories>();
            CreateMap<CandiateResource, Candidates>();
            CreateMap<VoterResource, Voters>();
            CreateMap<VoteResource, Votes>();
        }
    }
}