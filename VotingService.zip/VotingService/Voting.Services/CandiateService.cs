using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Voting.Core;
using Voting.Core.Models;
using Voting.Core.Services;

namespace Voting.Services
{
    public class CandiateService : ICandidateService
    {
        private readonly IUnitOfWork _unitOfWork;
        public CandiateService(IUnitOfWork unitOfWork)
        {
            this._unitOfWork = unitOfWork;
        }

        public async Task<Candidates> CreateCandidate(Candidates newCandidate)
        {
            await _unitOfWork.Candidates
                .AddAsync(newCandidate);
            await _unitOfWork.CommitAsync();

            return newCandidate;
        }

        public async Task<IEnumerable<Candidates>> GetCandidates()
        {
            return await _unitOfWork.Candidates.GetCandidatesAsync();
        }

        public async Task<Candidates> GetCandidateById(Guid Id)
        {
            return await _unitOfWork.Candidates.GetCandidateByIdAsync(Id);
        }
        public async Task<IEnumerable<Candidates>> GetCandidatesByCategoryId(Guid categoryId)
        {
            return await _unitOfWork.Candidates.GetCandidatesByCategoryAsync(categoryId);
        }
    }
}
