using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Voting.Core;
using Voting.Core.Models;
using Voting.Core.Services;

namespace Voting.Services
{
    public class CategoryService : ICategoryService
    {
        private readonly IUnitOfWork _unitOfWork;
        public CategoryService(IUnitOfWork unitOfWork)
        {
            this._unitOfWork = unitOfWork;
        }

        public async Task<Categories> CreateCategory(Categories newCategory)
        {
            await _unitOfWork.Categories
                .AddAsync(newCategory);
            await _unitOfWork.CommitAsync();                    
            
            return newCategory;
        }

        public async Task<IEnumerable<Categories>> GetCategories()
        {
            return await _unitOfWork.Categories.GetCategoriesAsync();
        }

        public async Task<Categories> GetCategoryById(Guid Id)
        {
            return await _unitOfWork.Categories.GetCategoryByIdAsync(Id);
        }
    }
}
