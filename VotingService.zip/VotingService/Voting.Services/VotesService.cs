using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Tasks;
using Voting.Core;
using Voting.Core.Models;
using Voting.Core.Services;

namespace Voting.Services
{
    public class VotesService : IVotesService
    {
        private readonly IUnitOfWork _unitOfWork;
        public VotesService(IUnitOfWork unitOfWork)
        {
            this._unitOfWork = unitOfWork;
        }

        public async Task<IEnumerable<Votes>> GetVotesForCandidate(Guid candidateId)
        {
            return await _unitOfWork.Votes.GetVotesByCandidateId(candidateId);
        }

        public async Task<Votes> GetVotesById(Guid Id)
        {
            return await _unitOfWork.Votes.GetVotesById(Id);
        }

        public async Task<IEnumerable<Votes>> GetVotesForCandidatePerCategoryByVoter(Guid VoterId, Guid CandidateId)
        {
            return await _unitOfWork.Votes.GetVotesForCandidatePerCategoryByVoter(VoterId, CandidateId);
        }

        public async Task<Votes> CreateVote(Votes voteToCreate)
        {
            var voter = await _unitOfWork.Voters.GetVoterById(voteToCreate.VoterId);
            var today = DateTime.Today;

            if (voter != null)
            {
                var age = today.Year - voter.DateOfBirth.Date.Year;

                if (voter.DateOfBirth > today.AddYears(-age)) age--;

                var votes = GetVotesForCandidatePerCategoryByVoter(voteToCreate.VoterId, voteToCreate.CandidateId);

                if (age < 18)
                {
                    //Voter's age is less than 18
                   // voteToCreate.CandidateId = Guid.Empty;
                    voteToCreate.VoterId = Guid.Empty;
                }
                else if (votes == null || votes.Result.Count() > 0)
                {
                    //Candidate with this category already been voted
                    voteToCreate.CandidateId = Guid.Empty;
                    // voteToCreate.CandidateId = voteToCreate.CandidateId;
                    //voteToCreate.VoterId = voteToCreate.VoterId;
                }
                else
                {
                    await _unitOfWork.Votes.AddAsync(voteToCreate);
                    await _unitOfWork.CommitAsync();
                }
            }
            return voteToCreate;
        }
    }
}
