using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Voting.Core;
using Voting.Core.Models;
using Voting.Core.Services;

namespace Voting.Services
{
    public class VoterService : IVoterService
    {
        private readonly IUnitOfWork _unitOfWork;
        public VoterService(IUnitOfWork unitOfWork)
        {
            this._unitOfWork = unitOfWork;
        }

        public async Task<IEnumerable<Voters>> GetVoters()
        {
            return await _unitOfWork.Voters.GetVotersAsync();
        }

        public async Task<Voters> GetVoterById(Guid voterId)
        {
            return await _unitOfWork.Voters.GetVoterById(voterId);
        }

        public async Task<Voters> CreateVoter(Voters newVoter)
        {
            await _unitOfWork.Voters
                .AddAsync(newVoter);
            await _unitOfWork.CommitAsync();

            return newVoter;
        }

        public async Task UpdateVoterAge(Voters voterToBeUpdated, Voters voter)
        {
            voterToBeUpdated.DateOfBirth = voter.DateOfBirth;

            await _unitOfWork.CommitAsync();
        }

        public async Task DeleteVoter(Voters voter)
        {
            _unitOfWork.Voters.Remove(voter);
            await _unitOfWork.CommitAsync();
        }
    }
}
